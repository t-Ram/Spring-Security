package com.annathe.training.shareprice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharepriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
