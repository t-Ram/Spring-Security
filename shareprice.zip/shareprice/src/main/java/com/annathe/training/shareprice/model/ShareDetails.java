package com.annathe.training.shareprice.model;

public class ShareDetails {
	
	
	private String stockName;
	
	private float price;

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	

}
